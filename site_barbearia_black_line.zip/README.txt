# Black Line Barbearia — site demonstrativo

Arquivos:
- index.html
- style.css
- script.js

## Como abrir
1. Extraia o ZIP.
2. Abra o arquivo `index.html` no navegador.

## Para personalizar para um cliente
No `index.html`, altere:
- Nome da barbearia
- Telefone/WhatsApp
- Endereço
- Horários
- Preços
- Instagram
- Textos e avaliações

Também troque as imagens do `style.css` pelas fotos reais do cliente.

## WhatsApp
Os links usam o número fictício 55 47 99999-9999. Troque pelo número real.

Observação: as imagens de demonstração são carregadas de URLs externas (Unsplash), então precisam de internet para aparecer.
